from fnpcell import all as fp

from IMECAS_SiN_pdk_1_0_0.technology.font.font_line_pixel_7 import FONT


class LABEL:
    FONT = FONT
    FONT_SIZE = 1.2
    BASELINE = fp.TextBaseline.BOTTOM
