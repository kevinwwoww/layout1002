# type: ignore
from .wg import (
    CoreCladdingTrenchWaveguideType as CoreCladdingTrenchWaveguideType,

)

