import math


class METRICS:
    GRID = 1e-9
    UNIT = 1e-6
    ANGLE_STEP = math.radians(1)
