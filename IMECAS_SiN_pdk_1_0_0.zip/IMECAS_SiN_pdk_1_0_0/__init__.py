"""
.. include:: ./README.md

# Changelog
```markdown
.. include:: ./CHANGELOG.md
```
"""

__version__ = "1.0.0"
